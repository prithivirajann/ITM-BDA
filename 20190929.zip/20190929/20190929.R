
install.packages("xlsx")
library("xlsx")
getwd()
setwd("C:/Users/lenovo/Desktop/ITM/Prithivirajan/20190929")
dataset<-read.xlsx("20 classification tree.xlsx", sheetIndex =1)

attach(dataset)
head(dataset)

install.packages("rpart")
library("rpart")

dtree<-rpart(ownership~Income+LotSize,method="class")
print(dtree)

dtree.pruned<-prune(dtree,cp=0.01)

install.packages("rpart.plot")
library("rpart.plot")

prp(dtree.pruned,type=2,extra=104,fallen.leaves=TRUE, main="Decision Tree")
install.packages("randomForest")
library("randomForest")

fit<-randomForest(ownership~Income+LotSize)
importance(fit,type=2)
