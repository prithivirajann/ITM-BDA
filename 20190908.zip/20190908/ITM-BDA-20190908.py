import pandas as pd

# to convert into matrix form
from mlxtend.preprocessing import TransactionEncoder

dataset = [['Milk','Bread','WheatBread'],['Milk','Jam','Bread','Butter'],['Milk','Jam','Bread','Butter'],['Jam','Butter']]
dataset

te=TransactionEncoder()
te_ary=te.fit(dataset).transform(dataset)

df=pd.DataFrame(te_ary)
df

df1 = pd.DataFrame(te_ary,columns=te.columns_)
df1

from mlextend.frequent_patterns import apriori

# support = number of transactions that have the products / total number of products 
apriori(df1,min_support=0.1, use_colnames=True)
frequent_itemsets=apriori(df1,min_support=0.1,use_colnames=True)
frequent_itemsets['length']=frequent_itemsets['itemsets'].apply(lambda x:len(x))

# combination of 3 items
frequent_itemsets[(frequent_itemsets['length']==3) &(frequent_itemsets['support']>=0.5)]

# combination of 2 items
frequent_itemsets[(frequent_itemsets['length']==2) &(frequent_itemsets['support']>=0.5)]