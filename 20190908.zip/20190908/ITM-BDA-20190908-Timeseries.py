
import pandas as pd

dataset=pd.read_excel('19 Time Series.xlsx',sheet_name=0)

dataset.head()

dataset['Sales'].mean()
# Out[7]: 48.333333333333336

dataset['Sales']= dataset['Sales'].fillna(dataset['Sales'].mean())
dataset

dataset.drop_duplicates()
'''
Out[11]: 
   Year  Time      Sales
0  1999     0  20.000000
1  2000     1  40.000000
2  2001     2  30.000000
3  2002     3  48.333333
4  2003     4  70.000000
5  2004     5  65.000000
'''

import matplotlib.pyplot as plt
plt.plot(dataset.Time,dataset.Sales)

'''   TO BE TESTED AS STATSMODEL didnot work '''
 
import statsmodels.api as sm
Y=dataset.Sales
X=dataset.Time
X1=sm.add_constant(X)
linear=sm.OLS(Y,X1)
result=linear.fit()
result.summary()
