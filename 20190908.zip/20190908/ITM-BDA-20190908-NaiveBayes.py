import pandas as pd

from sklearn import preprocessing

le=preprocessing.LabelEncoder()

from sklearn.metrics import confusion_matrix

from sklearn.metrics import accuracy_score

from sklearn.model_selection import train_test_split

dataset = pd.read_csv('train.csv')

dataset.head()

le.fit(dataset['Sex'])
print(le.classes_)
# Transform/Encode the Alphabetical value to Numeric for Gender column
dataset['Sex'] = le.transform(dataset['Sex'])

le.fit(dataset['Embarked'])
print(le.classes_)
# Transform/Encode the Alphabetical value to Numeric for Embarked column
dataset['Embarked']=le.transform(dataset['Embarked'])

Y=dataset['Pclass']

# Both DV & IDV are Categorical values Only
X=dataset.drop(['PassengerId','Pclass','Name','Age','Ticket','Fare','Cabin'], axis=1)
X.head()

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.3, random_state=0)

X_train.head()
X_test.head()
Y_train.head()
Y_test.head()

from sklearn.naive_bayes import *

clf=BernoulliNB()
y_pred=clf.fit(X_train,Y_train).predict(X_test)
accuracy_score(Y_test, y_pred, normalize=True)

confusion_matrix(Y_test,y_pred)
'''
Out[32]: 
array([[ 26,  10,  34],
       [  8,  10,  31],
       [ 20,   7, 121]], dtype=int64)
'''
    
# HOME-WORK
#Like PClass, take other dependent variables (like gender etc...) and check, which variable gives more accuracy