import pandas as pd

from sklearn import preprocessing

le=preprocessing.LabelEncoder()

from sklearn.metrics import confusion_matrix

from sklearn.metrics import accuracy_score

from sklearn.model_selection import train_test_split

dataset = pd.read_csv('train.csv')

dataset.head()

le.fit(dataset['Sex'])
print(le.classes_)
# Transform/Encode the Alphabetical value to Numeric for Gender column
dataset['Sex'] = le.transform(dataset['Sex'])

le.fit(dataset['Embarked'])
print(le.classes_)
# Transform/Encode the Alphabetical value to Numeric for Embarked column
dataset['Embarked']=le.transform(dataset['Embarked'])

Y=dataset['Pclass']

# DV - Categorical ; IDV can be both Continuous and Categorical
X=dataset.drop(['PassengerId','Pclass','Name','Ticket','Cabin'], axis=1)
X.head()

X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.3, random_state=0)

X_train.head()
X_test.head()
Y_train.head()
Y_test.head()

from sklearn import neighbors

knn = neighbors.KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train,Y_train).score(X_test,Y_test)
y_pred=knn.predict(X_test)

confusion_matrix(Y_test,y_pred)
'''
Out[30]: 
array([[ 63,   5,   2],
       [  7,  28,  14],
       [  3,   5, 140]], dtype=int64)
'''

knn = neighbors.KNeighborsClassifier(n_neighbors=4)
knn.fit(X_train,Y_train).score(X_test,Y_test)
y_pred=knn.predict(X_test)

confusion_matrix(Y_test,y_pred)
'''
Out[30]: 
array([[ 63,   5,   2],
       [  7,  28,  14],
       [  3,   5, 140]], dtype=int64)
'''

y_pred=clf.fit(X_train,Y_train).predict(X_test)
accuracy_score(Y_test, y_pred, normalize=True)

confusion_matrix(Y_test,y_pred)
'''
Out[32]: 
array([[ 26,  10,  34],
       [  8,  10,  31],
       [ 20,   7, 121]], dtype=int64)
'''

knn = neighbors.KNeighborsClassifier(n_neighbors=2)

knn.fit(X_train,Y_train).score(X_test,Y_test)